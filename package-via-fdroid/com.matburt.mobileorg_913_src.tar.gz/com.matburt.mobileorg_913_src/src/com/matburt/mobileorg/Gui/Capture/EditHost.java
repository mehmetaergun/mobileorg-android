package com.matburt.mobileorg.Gui.Capture;


public interface EditHost {
	public EditActivityController getController();
}
