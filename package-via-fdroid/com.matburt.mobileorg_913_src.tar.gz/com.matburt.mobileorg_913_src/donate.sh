find . -type f | xargs sed -i 's/com\.matburt\.mobileorg/com\.matburt\.mobileorg\.donate/g'
