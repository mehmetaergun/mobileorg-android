An implementation of MobileOrg for the Android platform

for installation instructions see the wiki page:

[http://wiki.github.com/matburt/mobileorg-android/](http://wiki.github.com/matburt/mobileorg-android)

We have a Google+ Page:

[MobileOrg on Google+](https://plus.google.com/u/0/101083268903948579162)

And a dedicated Google Group for discussions and announcements:

[http://groups.google.com/group/mobileorg-android](http://groups.google.com/group/mobileorg-android)

If you want to hack on the code:

[HACKING.md](mobileorg-android/blob/master/HACKING.md)
